#!/usr/bin/python3
""" Create a rectangle class """


class Rectangle:
    """Definition of class rectangle"""
    pass
