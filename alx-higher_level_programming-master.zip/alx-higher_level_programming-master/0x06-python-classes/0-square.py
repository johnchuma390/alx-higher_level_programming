#!/usr/bin/python3
""" Creating a square class """


class Square:
    """ Creating a square class """
    pass
