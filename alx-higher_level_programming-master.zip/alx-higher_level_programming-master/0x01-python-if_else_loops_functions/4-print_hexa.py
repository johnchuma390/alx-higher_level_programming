#!/usr/bin/python3
for m in range(0, 99):
    print("{} = {}".format(m, hex(m)))
