#!/usr/bin/python3

for m in range(97, 123):
    print("{}".format(chr(m)), end="")
