#!/usr/bin/python3
for m in range(97, 123):
    if (m != 101 and m != 113):
        print("{}".format(chr(m)), end='')
