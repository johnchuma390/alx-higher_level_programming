#!/usr/bin/node
const arrS = ['C is fun', 'Python is cool', 'JavaScript is amazing'];
for (let i = 0; i < arrS.length; i++) {
  console.log(arrS[i]);
}
