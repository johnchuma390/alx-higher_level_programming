#!/usr/bin/node
exports.add = function add (a, b) {
  return a + b;
};
