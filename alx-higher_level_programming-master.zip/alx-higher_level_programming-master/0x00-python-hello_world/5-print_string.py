#!/usr/bin/python3
str = "Holberton School"
print(("{}\n{}").format(str*3, str[:9]))
