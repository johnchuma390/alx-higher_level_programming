#!/usr/bin/python3
def number_keys(a_dictionary):
    """
    Return the number of keys in a dictionary
    """
    return len(a_dictionary)
