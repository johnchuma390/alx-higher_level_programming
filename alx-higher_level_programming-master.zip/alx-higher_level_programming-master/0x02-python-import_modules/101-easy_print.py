#!/usr/bin/python3
__import__('os').system('echo "#pythoniscool"')
