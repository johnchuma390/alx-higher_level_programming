#!/usr/bin/python3
""" Creating an empty class """


class BaseGeometry:
    """
    BaseGeometry class
    """
    pass
